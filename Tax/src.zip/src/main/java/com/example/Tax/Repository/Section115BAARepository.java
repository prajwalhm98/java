package com.example.Tax.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Tax.model.Section115BAA;


public interface Section115BAARepository extends JpaRepository<Section115BAA, Long> {

}
